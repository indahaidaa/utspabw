# website-company-profile
Apa yang perlu dilakukan?
1. Import data companyprofile.sql ke database yang kamu punya
2. Ubah koneksi ke di folder inc/inc_koneksi.php. Di variabel $host, $user, $pass $db, sesuaikan dengan koneksi yang kamu punya
3. Buka file di lokasi inc/inc_fungsi.php. Ubah isi $email_pengirim, dengan email mau, ubah isi $mail->Password dengan password yang kamu punya. 
4. Enable setting gmail yang kamu punya, supaya bisa mengirimkan email melalui PHP. link petunjuk ada di : https://www.youtube.com/watch?v=2LR5XHix3XI&t=9s mulai menit 26:43
5. Doakan keberkahan pada saya dan keluarga saya.
6. Jangan lupa klik subscribe channel saya :D https://www.youtube.com/c/ProgrammingDiRumahrafif
